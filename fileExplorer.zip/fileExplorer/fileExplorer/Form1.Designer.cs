﻿namespace fileExplorer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backButton = new System.Windows.Forms.Button();
            this.goButton = new System.Windows.Forms.Button();
            this.filePathTextBox = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lbl1 = new System.Windows.Forms.Label();
            this.fileNameLabel = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.fileTypeLabel = new System.Windows.Forms.Label();
            this.iconList = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.sizeLabel = new System.Windows.Forms.Label();
            this.directoriesInfo = new System.Windows.Forms.ListBox();
            this.directories = new System.Windows.Forms.ListBox();
            this.directoryName = new System.Windows.Forms.TextBox();
            this.newDirectory = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(873, 12);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 0;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // goButton
            // 
            this.goButton.Location = new System.Drawing.Point(955, 12);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(75, 23);
            this.goButton.TabIndex = 1;
            this.goButton.Text = "Go";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            // 
            // filePathTextBox
            // 
            this.filePathTextBox.Location = new System.Drawing.Point(15, 13);
            this.filePathTextBox.Name = "filePathTextBox";
            this.filePathTextBox.Size = new System.Drawing.Size(852, 22);
            this.filePathTextBox.TabIndex = 2;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.iconList;
            this.listView1.Location = new System.Drawing.Point(274, 52);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(756, 367);
            this.listView1.SmallImageList = this.iconList;
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.listView1_ItemSelectionChanged);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(12, 457);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(72, 16);
            this.lbl1.TabIndex = 4;
            this.lbl1.Text = "File Name:";
            // 
            // fileNameLabel
            // 
            this.fileNameLabel.AutoSize = true;
            this.fileNameLabel.Location = new System.Drawing.Point(109, 457);
            this.fileNameLabel.Name = "fileNameLabel";
            this.fileNameLabel.Size = new System.Drawing.Size(15, 16);
            this.fileNameLabel.TabIndex = 5;
            this.fileNameLabel.Text = "--";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(789, 457);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(67, 16);
            this.lbl2.TabIndex = 6;
            this.lbl2.Text = "File Type:";
            // 
            // fileTypeLabel
            // 
            this.fileTypeLabel.AutoSize = true;
            this.fileTypeLabel.Location = new System.Drawing.Point(870, 457);
            this.fileTypeLabel.Name = "fileTypeLabel";
            this.fileTypeLabel.Size = new System.Drawing.Size(15, 16);
            this.fileTypeLabel.TabIndex = 7;
            this.fileTypeLabel.Text = "--";
            // 
            // iconList
            // 
            this.iconList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iconList.ImageStream")));
            this.iconList.TransparentColor = System.Drawing.Color.Transparent;
            this.iconList.Images.SetKeyName(0, "unknown.png");
            this.iconList.Images.SetKeyName(1, "png.png");
            this.iconList.Images.SetKeyName(2, "folder64.png");
            this.iconList.Images.SetKeyName(3, "exe.png");
            this.iconList.Images.SetKeyName(4, "mp4.png");
            this.iconList.Images.SetKeyName(5, "mp3.png");
            this.iconList.Images.SetKeyName(6, "file.png");
            this.iconList.Images.SetKeyName(7, "doc.png");
            this.iconList.Images.SetKeyName(8, "pdf.png");
            this.iconList.Images.SetKeyName(9, "folder2.png");
            this.iconList.Images.SetKeyName(10, "folder.png");
            this.iconList.Images.SetKeyName(11, "jpg.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(405, 457);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Size (bytes):";
            // 
            // sizeLabel
            // 
            this.sizeLabel.AutoSize = true;
            this.sizeLabel.Location = new System.Drawing.Point(509, 457);
            this.sizeLabel.Name = "sizeLabel";
            this.sizeLabel.Size = new System.Drawing.Size(15, 16);
            this.sizeLabel.TabIndex = 9;
            this.sizeLabel.Text = "--";
            this.sizeLabel.Click += new System.EventHandler(this.sizeLabel_Click);
            // 
            // directoriesInfo
            // 
            this.directoriesInfo.FormattingEnabled = true;
            this.directoriesInfo.ItemHeight = 16;
            this.directoriesInfo.Location = new System.Drawing.Point(9, 224);
            this.directoriesInfo.Name = "directoriesInfo";
            this.directoriesInfo.Size = new System.Drawing.Size(256, 148);
            this.directoriesInfo.TabIndex = 11;
            this.directoriesInfo.SelectedIndexChanged += new System.EventHandler(this.directoriesInfo_SelectedIndexChanged);
            // 
            // directories
            // 
            this.directories.FormattingEnabled = true;
            this.directories.ItemHeight = 16;
            this.directories.Location = new System.Drawing.Point(9, 102);
            this.directories.Name = "directories";
            this.directories.Size = new System.Drawing.Size(256, 116);
            this.directories.TabIndex = 12;
            this.directories.SelectedIndexChanged += new System.EventHandler(this.directories_SelectedIndexChanged_1);
            // 
            // directoryName
            // 
            this.directoryName.Location = new System.Drawing.Point(9, 55);
            this.directoryName.Name = "directoryName";
            this.directoryName.Size = new System.Drawing.Size(159, 22);
            this.directoryName.TabIndex = 13;
            this.directoryName.TextChanged += new System.EventHandler(this.directoryName_TextChanged);
            // 
            // newDirectory
            // 
            this.newDirectory.Location = new System.Drawing.Point(174, 52);
            this.newDirectory.Name = "newDirectory";
            this.newDirectory.Size = new System.Drawing.Size(94, 28);
            this.newDirectory.TabIndex = 14;
            this.newDirectory.Text = "New";
            this.newDirectory.UseVisualStyleBackColor = true;
            this.newDirectory.Click += new System.EventHandler(this.newDirectory_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(12, 389);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(256, 30);
            this.deleteButton.TabIndex = 15;
            this.deleteButton.Text = "Delete Directory";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1042, 510);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.newDirectory);
            this.Controls.Add(this.directoryName);
            this.Controls.Add(this.directories);
            this.Controls.Add(this.directoriesInfo);
            this.Controls.Add(this.sizeLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fileTypeLabel);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.fileNameLabel);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.filePathTextBox);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.backButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.TextBox filePathTextBox;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ImageList iconList;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label fileNameLabel;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label fileTypeLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label sizeLabel;
        private System.Windows.Forms.ListBox directoriesInfo;
        private System.Windows.Forms.ListBox directories;
        private System.Windows.Forms.TextBox directoryName;
        private System.Windows.Forms.Button newDirectory;
        private System.Windows.Forms.Button deleteButton;
    }
}

