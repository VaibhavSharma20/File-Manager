﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Linq;


namespace fileExplorer
{
    public partial class Form1 : Form
    {
        private string filePath ;
        private bool isFile = false;
        private string currentlySelectedItemName = "";
        const String BACKSLASH = @"\";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //filePathTextBox.Text = filePath;
            
            var drives = Environment.GetLogicalDrives().ToList();
            drives.ForEach(drive =>
            {
                directories.Items.Add(drive);
            });

            //loadFilesandDirectories();
        }

        public void loadFilesandDirectories()
        {
            DirectoryInfo fileList;
            string tempFilePath = "";
            FileAttributes fileAttr;
            try
            {
                if (isFile)
                {
                     tempFilePath = Path.Combine(filePath,currentlySelectedItemName);
                   // tempFilePath = filePath + "/" + currentlySelectedItemName;
                    FileInfo fileDetails = new FileInfo(tempFilePath);
                    fileNameLabel.Text = fileDetails.Name;
                    fileTypeLabel.Text = fileDetails.Extension;
                    sizeLabel.Text = Convert.ToString(fileDetails.Length);
                    fileAttr = File.GetAttributes(tempFilePath);
                    Process.Start(tempFilePath);
                }
                else
                {
                    fileAttr= File.GetAttributes(filePath);
                    
                }

                if((fileAttr & FileAttributes.Directory)== FileAttributes.Directory)
                {
                    fileList = new DirectoryInfo(filePath);
                    FileInfo[] files = fileList.GetFiles();
                    DirectoryInfo[] dirs = fileList.GetDirectories();
                    string fileExtension = "";

                    fileNameLabel.Text = "--";
                    fileTypeLabel.Text = "--";
                    sizeLabel.Text = "--";  
                    listView1.Items.Clear();

                    foreach (FileInfo file in files)
                    {
                        fileExtension = file.Extension.ToUpper();
                        switch (fileExtension)
                        {
                            case ".MP3":
                                listView1.Items.Add(file.Name, 5);
                                break;
                            case ".MP4":
                                listView1.Items.Add(file.Name, 4);
                                break;
                            case ".EXE":
                                listView1.Items.Add(file.Name, 3);
                                break;
                            case ".PDF":
                                listView1.Items.Add(file.Name, 8);
                                break;
                            case ".DOC":
                                listView1.Items.Add(file.Name, 7);
                                break;
                            case ".DOCX":
                                listView1.Items.Add(file.Name, 7);
                                break;
                            case ".PNG":
                                listView1.Items.Add(file.Name, 1);
                                break;
                            case ".JPG":
                                listView1.Items.Add(file.Name, 11);
                                break;
                            case ".JPEG":
                                listView1.Items.Add(file.Name, 11);
                                break;
                            default:
                                listView1.Items.Add(file.Name, 0);
                                break;
                        }
                    }

                    foreach (DirectoryInfo dir in dirs)
                    {
                        listView1.Items.Add(dir.Name,9);
                    }
                }
                else
                {
                    fileNameLabel.Text = this.currentlySelectedItemName;
                }
            }
            catch (Exception ex)
            {

            }

        }

        public void loadButton()
        {
            //removeBackSlash();
            filePath = filePathTextBox.Text;
            loadFilesandDirectories();  
            isFile = false;

        }
        private void goButton_Click(object sender, EventArgs e)
        {
            loadButton();
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            currentlySelectedItemName = e.Item.Text;

            var fullPath = Path.Combine(filePath,currentlySelectedItemName);
            
            //var fullPath = filePath + "/" + currentlySelectedItemName;

            FileAttributes fileAttr = File.GetAttributes(fullPath);

            if((fileAttr & FileAttributes.Directory) == FileAttributes.Directory)
            {
                isFile = false;
                filePathTextBox.Text = fullPath;
            }
            else
            {
                isFile= true;
            }
        }

        public void removeBackSlash()
        {
            string path = filePathTextBox.Text;
            if(path.LastIndexOf(BACKSLASH)== path.Length - 1)
            {
                filePathTextBox.Text = path.Substring(0,path.Length-1);
            }
        }

        public void goBack()
        {
            try
            {
                string path = filePathTextBox.Text;
                path = path.Substring(0, path.LastIndexOf(BACKSLASH)+1);
                this.isFile = false;
                filePathTextBox.Text = path;
                if (path.Count(f=>(f==Convert.ToChar(BACKSLASH)))>=2)
                {
                    removeBackSlash();
                }

            }
            catch(Exception ex) 
            {
                
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            loadButton();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            goBack();
            loadButton();
        }

        private void sizeLabel_Click(object sender, EventArgs e)
        {

        }

        private void directoriesInfo_SelectedIndexChanged(object sender, EventArgs e)
        {
       
        }

        private void directories_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            var selectedItem = directories.SelectedItem.ToString();
            filePath = selectedItem;
            filePathTextBox.Text = filePath;
            DriveInfo info = new DriveInfo(selectedItem);
            directoriesInfo.Items.Clear();
            directoriesInfo.Items.Add($"Available Free Space: {info.AvailableFreeSpace}");
            directoriesInfo.Items.Add($"Drive Format: {info.DriveFormat}");
            directoriesInfo.Items.Add($"Drive Type: {info.DriveType}");
            directoriesInfo.Items.Add($"IsReady: {info.IsReady}");
            directoriesInfo.Items.Add($"Name: {info.Name}");
            directoriesInfo.Items.Add($"Tota Free Space: {info.TotalFreeSpace}");
            directoriesInfo.Items.Add($"Root Directory: {info.RootDirectory}");
            directoriesInfo.Items.Add($"Volume Label: {info.VolumeLabel}");
            directoriesInfo.Items.Add($"Total Size: {info.TotalSize}");
            loadFilesandDirectories();
        }

        private void newDirectory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(directoryName.Text))
            {
                MessageBox.Show("please select both root directory and directory name");
                return;
            }
            else
            {
                var tempFilePath = Path.Combine(filePathTextBox.Text, directoryName.Text);
                Directory.CreateDirectory(tempFilePath);
                loadFilesandDirectories();
                directoryName.Text = "";
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Directory.Delete(filePathTextBox.Text);
            }
            catch(Exception ex)
            {

            }
            loadFilesandDirectories();
            
        }

        private void directoryName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
